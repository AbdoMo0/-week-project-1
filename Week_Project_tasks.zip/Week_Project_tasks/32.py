import numpy as np

matrix = np.random.rand(3, 3)

print("Original matrix:")
print(matrix)
matrix[matrix > 0.5] = 1
matrix[matrix <= 0.5] = 0
print("\nModified matrix:")
print(matrix)
