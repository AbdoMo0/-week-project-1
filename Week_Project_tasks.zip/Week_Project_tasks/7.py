import numpy as np

random_number = np.random.rand()
print(random_number)
