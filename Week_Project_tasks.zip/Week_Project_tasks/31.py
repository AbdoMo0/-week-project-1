import numpy as np

data = np.loadtxt('data.txt')
array_3x9 = data.reshape(3, 9)

print(array_3x9)
