import numpy as np

array = np.array([1, 2, 3, 4, 1, 2, 1, 5])
value_to_count = 1
count = np.count_nonzero(array == value_to_count)
print(count)
