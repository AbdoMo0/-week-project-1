import numpy as np
from numpy.lib.stride_tricks import as_strided

Z = np.array([1,2,3,4,5,6,7,8,9,10,11,12,13,14])
shape = (11, 4)
strides = (Z.itemsize, Z.itemsize)
R = as_strided(Z, shape=shape, strides=strides)
print(R)
