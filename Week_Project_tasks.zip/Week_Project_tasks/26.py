import numpy as np

matrix = np.random.rand(4, 4)
print("Random 4x4 matrix:")
print(matrix)

diagonal_elements = np.diagonal(matrix)
print("\nDiagonal elements:")
print(diagonal_elements)
