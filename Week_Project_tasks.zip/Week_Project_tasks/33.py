import numpy as np

array_2d = np.random.rand(3, 3)

print("Original 2D array:")
print(array_2d)

max_value = array_2d.max()
min_value = array_2d.min()

print("\nMaximum value:", max_value)
print("Minimum value:", min_value)

array_2d[array_2d == max_value] = min_value

print("\nModified 2D array:")
print(array_2d)
