import numpy as np

int_array = np.arange(10, 51)
print(int_array)
