import numpy as np

even_array = np.arange(10, 51, 2)
print(even_array)
