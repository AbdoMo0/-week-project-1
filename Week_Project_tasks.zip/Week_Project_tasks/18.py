import numpy as np

array = np.array([1, 2, 3, 4, 5])
reversed_array = array[::-1]

print(reversed_array)
