import numpy as np

identity_matrix = np.eye(3)
print(identity_matrix)
