import numpy as np

zeros_array = np.zeros(10)
print(zeros_array)
