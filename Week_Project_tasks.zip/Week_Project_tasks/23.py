import numpy as np

matrix = np.zeros((5, 5)) + np.arange(5)
print(matrix)
