import numpy as np

matrix = np.arange(9).reshape(3, 3)
print(matrix)
