import numpy as np

array = np.array([1, -2, 3, -4, 5, -6, 7, -8, 9, -10])
boolean_array = array > 0
print(boolean_array)
