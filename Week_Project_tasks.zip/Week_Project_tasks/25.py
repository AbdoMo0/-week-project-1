import numpy as np

array_2d = np.array([
    [1, 2, 3],
    [4, 5, 6],
    [7, 8, 9]
])

row_means = np.mean(array_2d, axis=1)
print(row_means)
