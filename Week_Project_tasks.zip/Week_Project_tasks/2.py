import numpy as np

fives_array = np.full(10, 5)
print(fives_array)
