import numpy as np

linear_array = np.linspace(0, 1, 20)
print(linear_array)
