import numpy as np

random_array = np.random.rand(25)
print(random_array)
