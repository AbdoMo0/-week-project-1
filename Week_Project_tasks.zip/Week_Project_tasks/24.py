import numpy as np

array = np.array([1, 3, 2, 4, 5])
max_index = np.argmax(array)
print(max_index)
