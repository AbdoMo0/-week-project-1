class Solution(object):
 def kidsWithCandies(self, candies, extraCandies):
    max_candies = max(candies)
    result = []
    for num_candies in candies:
        if num_candies + extraCandies >= max_candies:
          result.append(True)
        else:
          result.append(False)
    return result

solution = Solution()
candies = [2, 3, 5, 1, 3]
extraCandies = 3
output = solution.kidsWithCandies(candies, extraCandies)
print(output)