class Solution(object):
    def mergeSimilarItems(self, items1, items2):
        item_map = {}
        for value, weight in items1:
            if value in item_map:
                item_map[value] += weight
            else:
                item_map[value] = weight
        for value, weight in items2:
            if value in item_map:
                item_map[value] += weight
            else:
                item_map[value] = weight
        sorted_items = sorted(item_map.items())
        ret = [[value, weight] for value, weight in sorted_items]
        return ret
items1 = [[1, 1], [4, 5], [3, 8]]
items2 = [[3, 1], [1, 5]]
solution = Solution()
output = solution.mergeSimilarItems(items1, items2)
print(output)