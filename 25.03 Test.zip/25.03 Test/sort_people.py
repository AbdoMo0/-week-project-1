class Solution:
    def sortPeople(self, names, heights):
        n = len(names)
        for i in range(n):
            for j in range(0, n-i-1):
                if heights[j+1] > heights[j]:
                    heights[j+1], heights[j] = heights[j], heights[j+1]
                    names[j+1], names[j] = names[j], names[j+1]
                    return names
names = ["Mary", "John", "Emma"]
heights = [180, 165, 170]
solution = Solution()
sorted_names = solution.sortPeople(names, heights)
print(sorted_names)
print(heights)