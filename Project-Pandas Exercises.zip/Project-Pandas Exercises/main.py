import pandas as pd
import matplotlib.pyplot as plt
exam_data = {'Date': ['2022-01-01', '2022-01-02', '2022-01-03', '2022-01-04', '2022-01-05'],
             'Subject': ['Math', 'Science', 'English', 'History', 'Geography'],
             'Mark': [85, 90, 75, 80, 88]}
exams = pd.DataFrame(exam_data)
online_food = pd.read_csv("online_food_dataset.csv")
columns_to_drop = ['longitude', 'latitude']
online_food.drop(columns_to_drop, axis=1, errors='ignore', inplace=True)
if 'age' in online_food.columns:
    min_age_customer = online_food.loc[online_food['age'].idxmin()]
    max_age_customer = online_food.loc[online_food['age'].idxmax()]
else:
    print("Column 'age' not found in the DataFrame.")
if 'occupation' in online_food.columns:
    mean_age_by_occupation = online_food.groupby('occupation')['age'].mean()
else:
    print("Column 'occupation' not found in the DataFrame.")
if all(col in online_food.columns for col in ['gender', 'monthly_income']):
    mean_family_size = online_food.groupby(['gender', 'monthly_income'])['family_size'].mean()
else:
    print("Columns 'gender' and/or 'monthly_income' not found in the DataFrame.")
if all(col in online_food.columns for col in ['marital_status', 'education_qualifications']):
    feedback_count = online_food.groupby(['marital_status', 'education_qualifications'])['positive_feedbacks'].count()
else:
    print("Columns 'marital_status' and/or 'education_qualifications' not found in the DataFrame.")
if 'family_size' in online_food.columns:
    online_food['Big family'] = online_food['family_size'] > 4
else:
    print("Column 'family_size' not found in the DataFrame.")
if all(col in online_food.columns for col in ['age', 'education_qualifications']):
    online_food.groupby('education_qualifications')['age'].mean().plot(kind='bar', title='Mean Age by Education Qualifications')
    plt.xlabel('Education Qualifications')
    plt.ylabel('Mean Age')
    plt.show()
else:
    print("Columns 'age' and/or 'education_qualifications' not found in the DataFrame.")
if all(col in online_food.columns for col in ['gender', 'positive_feedbacks', 'negative_feedbacks']):
    online_food.groupby('gender')[['positive_feedbacks', 'negative_feedbacks']].sum().plot(kind='bar', stacked=True)
    plt.title('Feedbacks by Gender')
    plt.xlabel('Gender')
    plt.ylabel('Feedback Count')
    plt.show()
else:
    print("Columns 'gender', 'positive_feedbacks', and/or 'negative_feedbacks' not found in the DataFrame.")
if all(col in online_food.columns for col in ['positive_feedbacks', 'family_size']):
    online_food.plot(kind='line', x='family_size', y='positive_feedbacks', title='Positive Feedbacks vs Family Size')
    plt.xlabel('Family Size')
    plt.ylabel('Positive Feedbacks')
    plt.show()
else:
    print("Columns 'positive_feedbacks' and/or 'family_size' not found in the DataFrame.")
